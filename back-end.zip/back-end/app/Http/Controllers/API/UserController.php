<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * LOGIN USER - POST
     * URL: http://127.0.0.1:8000/api/login
     */
    public function login(Request $request)
    {
        $user = User::select("*")->where([
                            ['email', $request->email],
                            ['password', $request->password]])->first();
        if ($user)
        {
            return response()->json([
                        "status" => 1,
                        "message" => "success",
                        "data" => $user
                    ], 200);
        }
        else {
            return response()->json([
                        "status" => 0,
                        "message" => "Login error",
                        "data" => $user
                    ], 401);
        }
    }

    /**
     * Display a listing of the resource - GET
     * URL: http://127.0.0.1:8000/api/users
     */
    public function index()
    {
        $datas = User::all();

        return response()->json([
            "status" => 1,
            "message" => "success",
            "data" => $datas
        ], 200);
    }

    /**
     * Store a newly created resource in storage - POST
     * URL: http://localhost:8000/api/user
     */
    public function store(Request $request)
    {
        $data = User::create($request->all());

        return response()->json([
            "status" => 1,
            "message" => "saved",
            "data" => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage - PUT
     * URL: http://localhost:8000/api/user/id
     */
    public function update(Request $request, $id)
    {
        if(User::where('id', $id)->exists()) {
            $data = User::find($id);

            $data->update($request->all());

            return response()->json([
                "status" => 1,
                "message" => "updated",
                "data" => $data
            ], 200);
        }
        else {
            return response()->json([
                "status" => 0,
                "message" => "Not found !"
            ], 404);
        }
    }

    /**
     * Remove the specified resource from storage - DELETE
     * URL: http://localhost:8000/api/user/id
     */
    public function destroy($id)
    {
        if(User::where('id', $id)->exists()) {

            User::destroy($id);

            return response()->json([
                "status" => 1,
                "message" => "Deleted !"
            ], 200);
        }
        else {

            return response()->json([
                "status" => 0,
                "message" => "not deleted"
            ], 404);
        }
    }
}