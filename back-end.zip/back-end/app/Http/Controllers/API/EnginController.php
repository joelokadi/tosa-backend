<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Engin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EnginController extends Controller
{
    /**
     * Display a listing of the resource - GET
     * URL: http://127.0.0.1:8000/api/engins
     */
    public function index()
    {
        $datas = DB::table('engins')
        ->join('personnes', 'personnes.id', '=', 'engins.personnes_id')
        ->select('engins.*', 'personnes.nom')
        ->get();

        return response()->json([
            "status" => 1,
            "message" => "success",
            "data" => $datas
        ], 200);
    }

    /**
     * Store a newly created resource in storage - POST
     * URL: http://localhost:8000/api/engin
     */
    public function store(Request $request)
    {
        $data = Engin::create($request->all());

        return response()->json([
            "status" => 1,
            "message" => "saved",
            "data" => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage - PUT
     * URL: http://localhost:8000/api/engin/id
     */
    public function update(Request $request, $id)
    {
        if(Engin::where('id', $id)->exists()) {
            $data = Engin::find($id);

            $data->update($request->all());

            return response()->json([
                "status" => 1,
                "message" => "updated",
                "data" => $data
            ], 200);
        }
        else {
            return response()->json([
                "status" => 0,
                "message" => "Not found !"
            ], 404);
        }
    }

    /**
     * Remove the specified resource from storage - DELETE
     * URL: http://localhost:8000/api/engin/id
     */
    public function destroy($id)
    {
        if(Engin::where('id', $id)->exists()) {

            Engin::destroy($id);

            return response()->json([
                "status" => 1,
                "message" => "Deleted !"
            ], 200);
        }
        else {

            return response()->json([
                "status" => 0,
                "message" => "not deleted"
            ], 404);
        }
    }
}