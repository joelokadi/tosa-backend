<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Amande;
use App\Models\Engin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AmandeController extends Controller
{
    /**
     * Display a listing of the resource - GET
     * URL: http://127.0.0.1:8000/api/amandes
     */
    public function index()
    {

        $datas = DB::table('amandes')
        ->join('personnes', 'personnes.id', '=', 'amandes.personnes_id')
        ->join('engins', 'engins.id', '=', 'amandes.engins_id')
        ->select('amandes.*', 'personnes.nom', 'engins.matricule')
        ->get();

        return response()->json([
            "status" => 1,
            "message" => "success",
            "data" => $datas
        ], 200);
    }

    /**
     * Store a newly created resource in storage - POST
     * URL: http://localhost:8000/api/amande
     */
    public function store(Request $request)
    {
        $data = Amande::create($request->all());

        return response()->json([
            "status" => 1,
            "message" => "saved",
            "data" => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage - PUT
     * URL: http://localhost:8000/api/amande/id
     */
    public function update(Request $request, $id)
    {
        if(Amande::where('id', $id)->exists()) {
            $data = Amande::find($id);

            $data->update($request->all());

            return response()->json([
                "status" => 1,
                "message" => "updated",
                "data" => $data
            ], 200);
        }
        else {
            return response()->json([
                "status" => 0,
                "message" => "Not found !"
            ], 404);
        }
    }

    /**
     * Store the image - POST
     * URL: http://localhost:8000/api/amande/image/id
     */
    public function storeImage(Request $request, $matricule)
    {
        $engin = Engin::where('matricule', $matricule)->first();
        $amande = new Amande;
        $amande->personnes_id = $engin->personnes_id;
        $amande->engins_id = $engin->id;
        $amande->image = $request->input('image');

        $amande->save();

        return response()->json([
            "status" => 1,
            "message" => "saved",
            "data" => $amande
        ], 200);

    }

    /**
     * Remove the specified resource from storage - DELETE
     * URL: http://localhost:8000/api/amande/id
     */
    public function destroy($id)
    {
        if(Amande::where('id', $id)->exists()) {

            Amande::destroy($id);

            return response()->json([
                "status" => 1,
                "message" => "Deleted !"
            ], 200);
        }
        else {

            return response()->json([
                "status" => 0,
                "message" => "not deleted"
            ], 404);
        }
    }
}