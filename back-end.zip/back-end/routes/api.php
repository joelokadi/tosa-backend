<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\EnginController;
use App\Http\Controllers\API\PersonneController;
use App\Http\Controllers\API\AmandeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Users api routes
Route::get("users", [UserController::class, "index"]);
Route::post("login", [UserController::class, "login"]);
Route::post("user", [UserController::class, "store"]);
Route::put("user/{id}", [UserController::class, "update"]);
Route::delete("user/{id}", [UserController::class, "destroy"]);

// Amandes api routes
Route::get("amandes", [AmandeController::class, "index"]);
Route::post("amande", [AmandeController::class, "store"]);
Route::put("amande/{id}", [AmandeController::class, "update"]);
Route::post("amande/image/{id}", [AmandeController::class, "storeImage"]);
Route::delete("amande/{id}", [AmandeController::class, "destroy"]);

// Personnes api routes
Route::get("/personnes", [PersonneController::class, "index"]);
Route::post("/personne", [PersonneController::class, "store"]);
Route::put("/personne/{id}", [PersonneController::class, "update"]);
Route::delete("/personne/{id}", [PersonneController::class, "destroy"]);

// Engins api routes
Route::get("engins", [EnginController::class, "index"]);
Route::post("engin", [EnginController::class, "store"]);
Route::put("engin/{id}", [EnginController::class, "update"]);
Route::delete("engin/{id}", [EnginController::class, "destroy"]);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});